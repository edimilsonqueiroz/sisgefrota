<div>
    Alterar senha
</div>
<?php /**PATH C:\projetos-laravel\sisgefrota\resources\views/livewire/alterar-senha.blade.php ENDPATH**/ ?>