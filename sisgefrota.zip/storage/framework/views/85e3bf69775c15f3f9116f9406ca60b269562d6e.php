<!DOCTYPE html>
<html>

<head>
    <meta charset="UTF-8">
    <title>Relatório de veículos</title>
    <link rel="stylesheet" type="text/css" href="css/relatorio.css">
</head>

<body>
    <!-- Define header and footer blocks before your content -->
    <header>
        <img class="logo-saude" src="imagens/logomarca.jpg">
        <img src="imagens/logodireita.jpg" class="logo-prefeitura">
        <div class="clear"></div>
    </header>


    <h1>VEÍCULOS CADASTRADOS - SISGEFROTA</h1>

    <table>
        <tr class="cabecalho">
            <th>Nome</th>
            <th>Placa</th>
            <th>Ano</th>
            <th>KM Rodados</th>
            <th>Situação</th>
        </tr>
        <?php $__currentLoopData = $veiculos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $veiculo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($veiculo->name); ?></td>
                <td><?php echo e($veiculo->placa); ?></td>
                <td><?php echo e($veiculo->ano); ?></td>
                <td><?php echo e($veiculo->km_rodado); ?></td>
                <td><?php echo e($veiculo->status); ?></td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </table>

    <h2 class='total'>Total de veículos: <?php echo e(count($veiculos)); ?></h2>
    <div class="credenciais">
        <hr>
        <p>Data emissão: <?php echo e(date('d/m/Y')); ?></p>
        <span>Horas: <?php echo e(date('H:i:s')); ?></span>
        <p>Relatório emitido por: <?php echo e(auth()->user()->name); ?></p>
    </div>



    <footer>
        <!--
        Copyright &copy; <?php echo date('Y'); ?>
        <span>Secretaria Municipal de Saúde - Palmeirante Tocantins</span><br>
        <span>Departamento de Sistema de Informação em Saúde</span><br>
        <span>Avenida Brasil, Telefone: 3493-1219</span>
      -->
    </footer>
</body>

</html>
<?php /**PATH C:\projetos-laravel\sisgefrota\resources\views/relatorios/relatorio-veiculos.blade.php ENDPATH**/ ?>