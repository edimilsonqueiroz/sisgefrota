<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Relatório de veículos</title>
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('css/relatorio.css')); ?>">
</head>
    <body>
    <!-- Define header and footer blocks before your content -->
    <header>
      <img class="logo-saude" src="<?php echo e(asset('imagens/logomarca.jpg')); ?>" >
      <img src="<?php echo e(asset('imagens/logodireita.jpg')); ?>"  class="logo-prefeitura">
      <div class="clear"></div>
    </header>
    
  
    <h1>VEÍCULOS CADASTRADOS - SISGEFROTA</h1>
      
        <table>
            <tr class="cabecalho">

                <th>Nome</th>
                <th>Placa</th>
                <th>Ano</th>
                <th>KM Rodados</th>
                <th>Situação</th>
            </tr>
                <tr>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                </tr>
        </table>

        
        <?php 
            //echo "<h2 class='total'>Total de veículos: ".count($veiculos)."</h2>";
         ?>

    <footer>
      <!--
        Copyright &copy; <?php echo date("Y");?>
        <span>Secretaria Municipal de Saúde - Palmeirante Tocantins</span><br>
        <span>Departamento de Sistema de Informação em Saúde</span><br>
        <span>Avenida Brasil, Telefone: 3493-1219</span>
      -->
    </footer>
    </body>
</html><?php /**PATH C:\projetos-laravel\sisgefrota\resources\views/relatorio-veiculos.blade.php ENDPATH**/ ?>