

<?php $__env->startSection('title', 'Dashboard'); ?>

<?php $__env->startSection('content_header'); ?>
<link rel="shortcut icon" type="image/x-icon" href="favicon.ico">
    <h1></h1>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <?php echo e($slot); ?>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('css'); ?>
    <link rel="stylesheet" href="<?php echo e(asset('css/style.css')); ?>">
    
<?php $__env->stopSection(); ?>
<?php $__env->startSection('js'); ?>
    <script>
            window.addEventListener('modal-editar',function() {
                $('#modal-editar').modal('show');
            })

            window.addEventListener('close-modal-editar',function() {
                $('#modal-editar').modal('hide');
            })
            
            window.addEventListener('close-modal-delete',function() {
                $('#modal-delete').modal('hide');
            })

            window.addEventListener('close-modal-reset', function() {
                $('#alterar-senha').modal('hide');
            })

            window.addEventListener('close-modal-imagem', function() {
                $('#editar-imagem').modal('hide');
            })

            window.addEventListener('modal-detalhes', function() {
                $('#modal-visualizar').modal('show');
            })

            window.addEventListener('modal-devolucao', function() {
                $('#modal-devolucao').modal('hide');
            })

            window.addEventListener('modal-enviar-aprovacao', function() {
                $('#modal-enviar-aprovacao').modal('hide');
            })

            window.addEventListener('modal-aprovacao', function() {
                $('#modal-aprovacao').modal('hide');
            })
    </script>
    
<?php $__env->stopSection(); ?>

<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\projetos-laravel\sisgefrota\resources\views/layouts/app.blade.php ENDPATH**/ ?>