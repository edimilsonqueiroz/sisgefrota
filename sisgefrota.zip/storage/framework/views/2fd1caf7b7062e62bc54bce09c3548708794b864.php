<div>
    Manutenção Maquinas
</div>
<?php /**PATH C:\projetos-laravel\sisgefrota\resources\views/livewire/manutencao-maquina.blade.php ENDPATH**/ ?>