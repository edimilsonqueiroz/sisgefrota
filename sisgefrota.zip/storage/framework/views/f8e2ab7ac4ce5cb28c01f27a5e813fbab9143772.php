<div>
    <div class="row">
        <div class="col-md-6">
            <button wire:click.prevent = "veiculosCadastrados" class="btn btn-sm btn-info mb-3">Veiculos cadastrados</button>
        </div>
    </div>
    <div class="card">
        <div class="card-header">
            <h5>Relatórios de veiculos</h5>
        </div>
        <div class="card-body">
            ....
        </div>
        <div class="card-footer">
            ......
        </div>
    </div>
</div>
<?php /**PATH C:\projetos-laravel\sisgefrota\resources\views/livewire/relatorio-veiculo.blade.php ENDPATH**/ ?>