<div style="margin-top:50px; width:100%; padding-top:100px; height:300px; background-color:#712419;">
    <h4 style="margin:30px 20px; background-color:white; padding:20px 0px; padding-left:5px;">
        Login: <?php echo e($login); ?>

    </h4>
    <h4 style="margin:8px 20px; background-color:white; padding:20px 0px; padding-left:5px;">
        Nova senha: <?php echo e($senha); ?>

    </h4>
</div>
<?php /**PATH C:\projetos-laravel\sisgefrota\resources\views/mail/email.blade.php ENDPATH**/ ?>