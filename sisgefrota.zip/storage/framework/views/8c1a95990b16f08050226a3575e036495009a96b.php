<!DOCTYPE html>
<html>

<head>
    <meta charset="UTF-8">
    <title>Relatório de veículos</title>
    <link rel="stylesheet" type="text/css" href="css/relatorio.css">
</head>

<body>
    <!-- Define header and footer blocks before your content -->
    <header>
        <img class="logo-saude" src="imagens/logomarca.jpg">
        <img src="imagens/logodireita.jpg" class="logo-prefeitura">
        <div class="clear"></div>
    </header>

    <h1>RELATÓRIO DE MANUTENÇÕES DE VEÍCULO - SISGEFROTA</h1>

    <fieldset style="width: 100%; padding:10px 10px; margin:30px 0px;">
        <legend style="padding:0px 10px;">DADOS DO VEÍCULO</legend>
        <table>
            <tr>
                <td><b>Nome do veículo:</b> <?php echo e($veiculo->name); ?></td>
                <td><b>Placa:</b> <?php echo e($veiculo->placa); ?></td>
                <td><b>Ano:</b> <?php echo e($veiculo->ano); ?></td>
            </tr>
        </table>
    </fieldset>
    <?php $__currentLoopData = $manutencoes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $manutencao): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <fieldset style="width: 100%; padding:15px 10px; margin:30px 0px;">
            <legend style="padding:2px 10px; border-radius:20px; background-color: #A24E44; color:white;">
                DADOS DA MANUTENÇÃO/REVISÃO
            </legend>
            <table style="border: 1px solid #ccc;">
                <tr>
                    <td style="border: 1px solid #ccc;" colspan="1"><b>Código:</b><?php echo e($manutencao['id']); ?></td>
                    <td style="border: 1px solid #ccc;" colspan="3"><b>Descricao da manutenção/revisão:</b>
                        <?php echo e($manutencao['descricao_manutencao']); ?>

                    </td>
                </tr>
                <tr>
                    <td colspan="2" style="border: 1px solid #ccc;">
                        <b>Motivo da Manutenção/Revisão:</b><br>
                        <?php if($manutencao['tipo_manutencao'] == 1): ?>
                            Revisão Periódica
                        <?php elseif($manutencao['tipo_manutencao'] == 2): ?>
                            Veiculo apresentou defeito
                        <?php endif; ?>
                    </td>
                    <td colspan="2" style="border: 1px solid #ccc;">
                        <b>Justificativa:</b><br>
                        <?php echo e($manutencao['justificativa']); ?>

                    </td>
                </tr>
                <tr>
                    <td colspan="2" style="border: 1px solid #ccc;">
                        <b>Status:</b><br>
                        <?php if($manutencao['status'] == 1): ?>
                            Aguardando aprovação
                        <?php elseif($manutencao['status'] == 2): ?>
                            Aprovada
                        <?php elseif($manutencao['status'] == 3): ?>
                            Devolvida para correção
                        <?php endif; ?>
                    </td>

                    <td colspan="2" style="border: 1px solid #ccc;">
                        <b>Cadastrado por:</b><br>
                        <?php echo e($manutencao['usuario']->name); ?>

                    </td>

                </tr>
                <tr>
                    <td colspan="2" style="border: 1px solid #ccc;">
                        <b>Aprovado por:</b><br>
                        <?php echo e($manutencao['user_aprovacao']->name); ?>

                    </td>
                    <td colspan="2" style="border: 1px solid #ccc;">
                        <b>Devolvido por:</b><br>
                        <?php echo e($manutencao['user_devolucao']); ?>

                    </td>
                </tr>
                <tr>
                    <td colspan="4">
                        <b>Data de criação:</b>
                        <?php echo e(date('d/m/Y', strtotime($manutencao['data_criacao']))); ?>

                    </td>
                </tr>
            </table>
            <fieldset style="padding:10px 10px;">
                <legend style="padding:0px 10px;">SERVIÇOS REALIZADOS</legend>
                <table>
                    <?php $__currentLoopData = $manutencao['servicos']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $servico): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td>» <?php echo e($servico->descricao); ?></td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </table>
            </fieldset>

        </fieldset>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <h2 class='total'>Total de manutenções: <?php echo e(count($manutencoes)); ?></h2>
    <div class="credenciais">
        <hr>
        <p>Data emissão: <?php echo e(date('d/m/Y')); ?></p>
        <span>Horas: <?php echo e(date('H:i:s')); ?></span>
        <p>Relatório emitido por: <?php echo e(auth()->user()->name); ?></p>
    </div>

    <footer>
        <!--
        Copyright &copy; <?php echo date('Y'); ?>
        <span>Secretaria Municipal de Saúde - Palmeirante Tocantins</span><br>
        <span>Departamento de Sistema de Informação em Saúde</span><br>
        <span>Avenida Brasil, Telefone: 3493-1219</span>
      -->
    </footer>
</body>

</html>
<?php /**PATH C:\projetos-laravel\sisgefrota\resources\views/relatorios/manutencoes-veiculo.blade.php ENDPATH**/ ?>