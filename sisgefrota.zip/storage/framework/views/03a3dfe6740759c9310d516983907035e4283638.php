<div>
   Relatório Máquina
</div>
<?php /**PATH C:\projetos-laravel\sisgefrota\resources\views/livewire/relatorio-maquina.blade.php ENDPATH**/ ?>