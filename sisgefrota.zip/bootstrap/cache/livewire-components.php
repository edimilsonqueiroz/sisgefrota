<?php return array (
  'dashboard' => 'App\\Http\\Livewire\\Dashboard',
  'manutencao-maquina' => 'App\\Http\\Livewire\\ManutencaoMaquina',
  'manutencao-veiculo' => 'App\\Http\\Livewire\\ManutencaoVeiculo',
  'maquinas' => 'App\\Http\\Livewire\\Maquinas',
  'perfil' => 'App\\Http\\Livewire\\Perfil',
  'relatorio-maquina' => 'App\\Http\\Livewire\\RelatorioMaquina',
  'relatorio-veiculo' => 'App\\Http\\Livewire\\RelatorioVeiculo',
  'usuarios' => 'App\\Http\\Livewire\\Usuarios',
  'veiculos' => 'App\\Http\\Livewire\\Veiculos',
);