<div style="margin-top:50px; width:100%; padding-top:100px; height:300px; background-color:#712419;">
    <h4 style="margin:30px 20px; background-color:white; padding:20px 0px; padding-left:5px;">
        Login: {{ $login }}
    </h4>
    <h4 style="margin:8px 20px; background-color:white; padding:20px 0px; padding-left:5px;">
        Nova senha: {{ $senha }}
    </h4>
</div>
