<div>
    <div class="row">
        <div class="col-md-6">
            <input class="form-control mb-2" type="search" wire:model="search" placeholder="Pesquisar">
        </div>
        <div class="col-md-6 text-right mb-2">
            <button data-toggle="modal" data-target="#cadastrar-veiculo" class="btn btn-sm btn-info">
                <i class="fas fa-plus-circle"></i>
                CADASTRAR MÁQUINA
            </button>
        </div>
        <div class="col-12">
            <div class="card">
                <div class="card-header">
                    <div class="row">
                        <div class="col-md-3">
                            <h3 class="card-title">Máquinas cadastrados</h3>
                        </div>
                        <div class="col-md-9">
                            @if (session()->has('mensagem-sucesso'))
                            <div wire:poll.disable class="text-success">
                                <i class="fas fa-check"></i>
                                {{ session('mensagem-sucesso') }}
                            </div>
                            @endif
                        </div>
                    </div>
                </div>
                <div class="card-body">
                    <div class="row">
                        <div class="col-md-4">
                            <div style="background-color: #ebe4e4;"
                            class="card card-widget widget-user-2 shadow-sm">

                            <div class="widget-user-header">
                                <div data-toggle="modal" data-target="#editar-imagem" style="cursor: pointer;">
                                    <i class="far fa-edit"></i>
                                    Editar Imagem
                                </div>
                            </div>
                            <div class="text-center">
                                <h3>Maquina 1</h3>
                                <p>MVT2030</p>
                            </div>
                            <div class="card-footer p-0">
                                <ul class="nav flex-column">
                                    <li class="nav-item">
                                        <a style="cursor: pointer;" class="nav-link h5">
                                            Horimetro 
                                            <span class="float-right badge bg-primary">15000</span>
                                        </a>
                                    </li>
                                    <li class="nav-item p-2 text-center">
                                        <button data-toggle="modal"
                                        data-target="#editar-veiculo" class="btn btn-sm btn-warning">
                                        <i class="fas fa-edit"></i>
                                        Editar
                                    </button>
                                    <button data-toggle="modal"
                                    data-target="#modal-delete" class="btn btn-sm btn-danger">
                                    <i class="fas fa-trash-alt"></i>
                                    Excluir
                                </button>
                            </li>
                        </ul>
                    </div>
                </div>
            </div>

        </div>
    </div>
    <div class="card-footer bg-white">
        ...
    </div>
</div>
</div>
</div>
</div>
