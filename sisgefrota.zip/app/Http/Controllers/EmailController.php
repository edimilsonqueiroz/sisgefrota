<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Mail;
use App\Mail\Email;
use App\Models\User;

class EmailController extends Controller
{
    public function render(){
        return view('email-mensagem');
    }

    public function enviarEmail(Request $request){
        $user = User::where('email', $request->input('email'))->first();
        $array = [
            'email' => $user->email,
            'senha' => $this->gerar_senha(8, true, true,true, true)
        ];
        
        Mail::send(new Email($array));
        return redirect()->route('email-render');
    }

    public static function gerar_senha($tamanho, $maiusculas, $minusculas, $numeros, $simbolos)
    {
        $password = '';
        $ma = "ABCDEFGHIJKLMNOPQRSTUVYXWZ"; // $ma contem as letras maiúsculas
        $mi = "abcdefghijklmnopqrstuvyxwz"; // $mi contem as letras minusculas
        $nu = "0123456789"; // $nu contem os números
        $si = "@#$%&"; // $si contem os símbolos

        if ($maiusculas) {
            // se $maiusculas for "true", a variável $ma é embaralhada e adicionada para a variável $senha
            $password .= str_shuffle($ma);
        }

        if ($minusculas) {
            // se $minusculas for "true", a variável $mi é embaralhada e adicionada para a variável $senha
            $password .= str_shuffle($mi);
        }

        if ($numeros) {
            // se $numeros for "true", a variável $nu é embaralhada e adicionada para a variável $senha
            $password .= str_shuffle($nu);
        }

        if ($simbolos) {
            // se $simbolos for "true", a variável $si é embaralhada e adicionada para a variável $senha
            $password .= str_shuffle($si);
        }

        // retorna a senha embaralhada com "str_shuffle" com o tamanho definido pela variável $tamanho
        return substr(str_shuffle($password), 0, $tamanho);
    }
}
